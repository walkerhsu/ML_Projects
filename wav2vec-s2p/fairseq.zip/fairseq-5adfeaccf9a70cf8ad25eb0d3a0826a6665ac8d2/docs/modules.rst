Modules
=======

Fairseq provides several stand-alone :class:`torch.nn.Module` classes that may
be helpful when implementing a new :class:`~fairseq.models.BaseFairseqModel`.

.. automodule:: fairseq.modules
    :members:
    :undoc-members:
